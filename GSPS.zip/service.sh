#!/system/bin/sh

MODDIR=${0%/*}

sleep 20

log() {
  echo "[SERVICE] $1" >> $MODDIR/log/runtime.log
}

log "service start"

# watcher 启动顺序是纪律
sh $MODDIR/scripts/screen_watcher.sh &
sh $MODDIR/scripts/game_watcher.sh &
sh $MODDIR/scripts/sleep_watcher.sh &
sh $MODDIR/scripts/daily_watcher.sh &

# 守护进程
$MODDIR/bin/gsps_guard >> $MODDIR/log/runtime.log 2>&1 &
$MODDIR/bin/gspsd >> $MODDIR/log/runtime.log 2>&1 &
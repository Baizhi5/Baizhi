#!/system/bin/sh
MODDIR=${0%/*}
rm -rf $MODDIR/log
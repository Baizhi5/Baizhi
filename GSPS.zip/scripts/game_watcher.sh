#!/system/bin/sh

CONF="/data/adb/modules/GSPS/conf/game_list.conf"
STATE="/data/adb/modules/GSPS/state/game.state"

while true; do
    GAME_FOUND=0
    for pkg in $(cat "$CONF"); do
        pidof "$pkg" >/dev/null 2>&1 && GAME_FOUND=1
    done

    if [ "$GAME_FOUND" -eq 1 ]; then
        echo "RUNNING" > "$STATE"
    else
        echo "IDLE" > "$STATE"
    fi

    sleep 2
done
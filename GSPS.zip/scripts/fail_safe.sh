#!/system/bin/sh

LOG="/data/adb/modules/GSPS/log/fault.log"

echo "[FAIL_SAFE] triggered at $(date)" >> "$LOG"
# 兜底：什么都不做 = 最安全
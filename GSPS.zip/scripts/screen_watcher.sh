#!/system/bin/sh

STATE_DIR="/data/adb/modules/GSPS/state"
SCREEN_STATE="$STATE_DIR/screen.state"

while true; do
    dumpsys power | grep -q "mHoldingDisplaySuspendBlocker=true"
    if [ $? -eq 0 ]; then
        echo "ON" > "$SCREEN_STATE"
    else
        echo "OFF" > "$SCREEN_STATE"
    fi
    sleep 1
done
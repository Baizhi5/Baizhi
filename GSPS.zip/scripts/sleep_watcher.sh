#!/system/bin/sh

STATE_DIR="/data/adb/modules/GSPS/state"
CUR="$STATE_DIR/current.state"
SCR="$STATE_DIR/screen.state"

while true; do
    if [ "$(cat "$SCR")" = "OFF" ]; then
        echo "SLEEP" > "$CUR"
    fi
    sleep 2
done
#!/system/bin/sh

STATE_DIR="/data/adb/modules/GSPS/state"
CUR="$STATE_DIR/current.state"
GAME="$STATE_DIR/game.state"

while true; do
    if [ "$(cat "$GAME")" = "IDLE" ]; then
        echo "DAILY" > "$CUR"
    fi
    sleep 5
done
#!/system/bin/sh

MODDIR=${0%/*}

mkdir -p $MODDIR/log
chmod -R 0755 $MODDIR

echo "[BOOT] post-fs-data reached" >> $MODDIR/log/boot.log

# 仅启动探针，不动策略
$MODDIR/bin/gsps_probe >> $MODDIR/log/boot.log 2>&1 &
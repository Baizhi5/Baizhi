#!/system/bin/sh

MODDIR=${0%/*}

ui_print "- GSPS: environment probing (no hard trust)"

mkdir -p $MODDIR/{conf,detect,state,log,bin,lib}

# Android / ABI
getprop ro.build.version.release > $MODDIR/detect/android.ver
getprop ro.product.cpu.abi > $MODDIR/detect/abi.cap

# Root environment (记录，不判断)
if [ -d /data/adb/apatch ]; then
  echo "APATCH=1" > $MODDIR/detect/root.cap
elif [ -d /data/adb/magisk ]; then
  echo "MAGISK=1" > $MODDIR/detect/root.cap
else
  echo "ROOT=UNKNOWN" > $MODDIR/detect/root.cap
fi

# sysfs writable probe
touch /sys/devices/system/cpu/cpu0/online 2>/dev/null \
  && echo "SYSFS_RW=1" > $MODDIR/detect/sysfs.cap \
  || echo "SYSFS_RW=0" > $MODDIR/detect/sysfs.cap

# LSM probe
[ -d /sys/kernel/security ] \
  && echo "LSM=1" > $MODDIR/detect/lsm.cap \
  || echo "LSM=0" > $MODDIR/detect/lsm.cap

# framework probe (只记录)
which dumpsys >/dev/null 2>&1 \
  && echo "FRAMEWORK=1" > $MODDIR/detect/framework.cap \
  || echo "FRAMEWORK=0" > $MODDIR/detect/framework.cap

# feature mask（不决定安装）
cat <<EOF > $MODDIR/conf/feature_mask.conf
ENABLE_SYSFS=$(grep -q SYSFS_RW=1 $MODDIR/detect/sysfs.cap && echo 1 || echo 0)
ENABLE_LSM=$(grep -q LSM=1 $MODDIR/detect/lsm.cap && echo 1 || echo 0)
ENABLE_FRAMEWORK=$(grep -q FRAMEWORK=1 $MODDIR/detect/framework.cap && echo 1 || echo 0)
EOF

# 初始化状态
echo "SCREEN=UNKNOWN" > $MODDIR/state/screen.state
echo "GAME_ACTIVE=0" > $MODDIR/state/game.state
echo "MODE=DAILY" > $MODDIR/state/current.state

ui_print "- GSPS: probe done (no trust assumed)"
#!/system/bin/sh
rm -f /data/adb/procwatch-extreme.log
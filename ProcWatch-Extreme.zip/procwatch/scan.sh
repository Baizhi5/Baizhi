#!/system/bin/sh

TS=$(date '+%F %T')
echo "===== [$TS] ProcWatch Extreme Scan START ====="

echo "[*] Kernel: $(uname -r)"
echo "[*] Root Env:"
ls /data/adb 2>/dev/null

echo
echo "[*] Scanning processes..."

for p in /proc/[0-9]*; do
  pid=${p##*/}
  [ -r "$p/status" ] || continue

  uid=$(awk '/Uid:/ {print $2}' "$p/status" 2>/dev/null)
  ppid=$(awk '/PPid:/ {print $2}' "$p/status" 2>/dev/null)

  cmd=$(tr '\0' ' ' < "$p/cmdline" 2>/dev/null)
  exe=$(readlink "$p/exe" 2>/dev/null)

  # 跳过明确的 kernel 线程
  echo "$cmd" | grep -q "^\[" && continue

  suspicious=0

  # 无 cmdline
  [ -z "$cmd" ] && suspicious=1

  # 可执行路径异常
  echo "$exe" | grep -Eq "^/data/local/tmp|^/proc/self/fd|^/dev" && suspicious=1

  # app uid 但无包名痕迹
  if [ "$uid" -ge 10000 ] && ! echo "$cmd" | grep -q "/data/app"; then
    suspicious=1
  fi

  if [ "$suspicious" -eq 1 ]; then
    echo "---"
    echo "[PID] $pid  UID=$uid  PPID=$ppid"
    echo "[CMD] $cmd"
    echo "[EXE] $exe"

    echo "[FD]"
    ls -l "$p/fd" 2>/dev/null | head -n 20
  fi
done

echo
echo "[*] Scanning root filesystem for running executables..."

find / -xdev -type f -perm -111 2>/dev/null | while read f; do
  lsof "$f" 2>/dev/null | grep -q "$f" && echo "[RUNNING BIN] $f"
done

echo "===== [$TS] ProcWatch Extreme Scan END ====="
echo
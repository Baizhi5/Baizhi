#!/system/bin/sh

MODDIR=${0%/*}
LOG="/data/adb/procwatch-extreme.log"

mkdir -p /data/adb
touch "$LOG"
chmod 600 "$LOG"

(
  while true; do
    sh "$MODDIR/procwatch/scan.sh" >> "$LOG" 2>&1
    sleep 3600
  done
) &